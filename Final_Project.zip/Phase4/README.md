# IoTFinalProject

## Resources
https://dash-bootstrap-components.opensource.faculty.ai/docs/components/navbar/

https://dash.plotly.com/dash-html-components/button

https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token

EMAIL = 'testemail3731@gmail.com'
PASSWORD = 'gewdapbnejriofzc'
