# pytorch
# cmd installations
# pip install pydash
# pip install dash_daq
# sudo apt-get remove thonny
# sudo apt-get install thonny
# pip install dash-bootstrap-components
# pip install dash_mqtt
# pip install paho-mqtt

import dash.dependencies
import dash_daq as daq
from dash import html, Input, Output, dcc, Dash, State
import dash_bootstrap_components as dbc
import RPi.GPIO as GPIO
import Freenove_DHT as DHT
import time as time
import smtplib
import email
import imaplib
import dash_mqtt
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import sqlite3

is_sent = True

Motor1 = 15  # Enable Pin | 22 board
Motor2 = 13  # Input Pin  | 27 board
Motor3 = 11  # Input Pin  | 17 board
# setup GPIO outputs
lightpin = 12
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(lightpin, GPIO.OUT)
lightsensor = 0
LEDStatus = False
hasLEDEmailSent = False
hastempEmailSent = True
humi = 0
temp = 0
count = 0
recieved = True

RFID = ""
name = ""
humipref = 9999
temppref = 9999
lightpref = 0

DHTPin = 40  # define the pin of DHT11
dht = DHT.DHT(DHTPin)  # create a DHT class object

def motor_on():
    global recieved
    global Motor1  # Enable Pin | 22 board
    global Motor2  # Input Pin  | 27 board
    global Motor3  # Input Pin  | 17 board
    GPIO.setup(Motor1, GPIO.OUT)
    GPIO.setup(Motor2, GPIO.OUT)
    GPIO.setup(Motor3, GPIO.OUT)

    GPIO.output(Motor1, GPIO.HIGH)
    GPIO.output(Motor2, GPIO.LOW)
    GPIO.output(Motor3, GPIO.HIGH)
    recieved = False


def send_email():
    global temp
    # Set up the email addresses and password
    my_address = "iotburner28@gmail.com"  # Replace with your own Gmail address
    my_password = "uefa acwp roct hnuc"  # Replace with your Gmail password
    recipient_address = "ilikefortniteseason4@gmail.com"  # Replace with the recipient's email address

    # Create the email message
    msg = MIMEMultipart()
    msg["From"] = my_address
    msg["To"] = recipient_address
    msg["Subject"] = "IoT Fan"

    # Add the body to the email
    body = "The current temperature is " + str(temp) + ". Would you like to turn on the fan?"
    msg.attach(MIMEText(body, "plain"))

    # Log in to the Gmail SMTP server
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(my_address, my_password)

    # Send the email
    text = msg.as_string()
    server.sendmail(my_address, recipient_address, text)

    # Log out of the server
    print("sent to " + recipient_address)
    server.quit()


def useremail():
    global name
    # Set up the email addresses and password
    my_address = "iotburner28@gmail.com"  # Replace with your own Gmail address
    my_password = "uefa acwp roct hnuc"  # Replace with your Gmail password
    recipient_address = "ilikefortniteseason4@gmail.com"  # Replace with the recipient's email address

    # Create the email message
    msg = MIMEMultipart()
    msg["From"] = my_address
    msg["To"] = recipient_address
    msg["Subject"] = "User Sign in"

    # Add the body to the email
    body = f"Welcome, {name}!"
    msg.attach(MIMEText(body, "plain"))

    # Log in to the Gmail SMTP server
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(my_address, my_password)

    # Send the email
    text = msg.as_string()
    server.sendmail(my_address, recipient_address, text)

    # Log out of the server
    print("sent to " + recipient_address)
    server.quit()


def receive_reply():
    EMAIL = "iotburner28@gmail.com"  # Replace with your own Gmail address
    PASSWORD = "uefa acwp roct hnuc"  # Replace with your Gmail password
    SERVER = "imap.gmail.com"

    # connect to the server and go to its inbox
    mail = imaplib.IMAP4_SSL(SERVER)
    mail.login(EMAIL, PASSWORD)

    mail.select("inbox")
    status, data = mail.search(None, "ALL")
    mail_ids = []

    for block in data:
        mail_ids += block.split()

    for i in mail_ids:
        status, data = mail.fetch(i, "(RFC822)")

        for response_part in data:
            if isinstance(response_part, tuple):
                message = email.message_from_bytes(response_part[1])

                mail_from = message["from"]
                mail_subject = message["subject"]

                if message.is_multipart():
                    mail_content = ""

                    for part in message.get_payload():
                        if part.get_content_type() == "text/plain":
                            mail_content += part.get_payload()
                else:
                    mail_content = message.get_payload()

                if (
                    mail_content == "yes"
                    or "yes" in mail_subject.lower()
                    or any(
                        "yes" in recipient.lower()
                        for recipient in message.get_all("to", [])
                    )
                    or "yes" in mail_content.lower()
                ):
                    print(f"From: {mail_from}")
                    print(f"Subject: {mail_subject}")
                    print(f"Content: {mail_content}")
                    # can start motor
                    motor_on()


def on_message(client, userdata, msg):
    global hasLEDEmailSent
    global is_sent
    global lightsensor
    global LEDStatus
    global temp
    global humi
    global RFID
    global temppref
    global humipref
    global lightpref
    global hastempEmailSent
    global count
    global recieved

    date = time.strftime("%d/%m/%Y %H:%M:%S")
    print(msg.payload.decode("utf-8"))
    print(msg.topic)

    if "photoValue" in msg.topic:
        lightsensor = float(msg.payload.decode("utf-8"))
        #print(lightsensor + float(0))

        if lightsensor <= lightpref:
            current_time = datetime.now().strftime("%H:%M")
            light_email(current_time)
            hasLEDEmailSent = True
            LEDStatus = True
            time.sleep(3)
        else:
            LEDStatus = False

    if "humidity1" in msg.topic:
        humi = float(msg.payload.decode("utf-8"))
    if "temperature1" in msg.topic:
        temp = float(msg.payload.decode("utf-8"))
    if "RFID" in msg.topic:
        RFID = str(msg.payload.decode("utf-8"))
        on_rfid_scanned(RFID)
        useremail()
    
    print("Humidity:", humi)
    print("RFID:", RFID)
    print("Temperature:", temp)
    print("sensor:", lightsensor)
    print("pref:", lightpref)

    if temp >= temppref and hastempEmailSent:
        send_email()
        hastempEmailSent = False
    receive_reply()
    #print("this is another test")


def get_user_data(RFID):
    # Connect to the database
    conn = sqlite3.connect(
        "/home/pi/Desktop/Phase4/app/data/users.db"
    )
    c = conn.cursor()

    # Execute the SQL query to get the user data
    c.execute("SELECT * FROM users WHERE user_id=?", (RFID,))
    user_data = c.fetchone()

    # Close the database connection
    conn.close()

    # Format the user data as a dictionary
    if user_data:
        # useremail(user_data[1])
        print(user_data[1])
        return user_data  # dict
    else:
        return None

    # return user_data


def on_rfid_scanned(RFID):
    global temppref
    global humipref
    global lightpref
    # global RFID
    global name
    user_data = get_user_data(RFID)
    if user_data:
        print("User data:", user_data)
        # Do something with the user data
        RFID = user_data[0]
        name = user_data[1]
        temppref = user_data[2]
        humipref = user_data[3]
        lightpref = user_data[4]
        print(lightpref)
    else:
        print("User not found in database")


def light_email(current_time):
    # Set up the email addresses and password
    my_address = "iotburner28@gmail.com"  # Replace with your own Gmail address
    my_password = "uefa acwp roct hnuc"  # Replace with your Gmail password
    recipient_address = (
        "ilikefortniteseason4@gmail.com"  # Replace with the recipient's email address
    )
    print("method was called")
    # Create the email message
    msg = MIMEMultipart()
    msg["From"] = my_address
    msg["To"] = recipient_address
    msg["Subject"] = "IoT Lightsensor"

    # Add the body to the email
    body = f"The Light is ON at {current_time}."
    msg.attach(MIMEText(body, "plain"))

    # Log in to the Gmail SMTP server
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(my_address, my_password)

    # Send the email
    text = msg.as_string()
    server.sendmail(my_address, recipient_address, text)

    # Log out of the server
    print("sent to " + recipient_address)
    server.quit()

    # Publish a message to a topic that the dashboard is subscribed to
    #publish.single("dashboard/message", "Email has been sent", hostname="localhost")


def on_connect(client, userdata, flags, rc):
    global lightpref
    print("Connected with result code " + str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    # client.subscribe("IoTlab/photoValue")
    client.subscribe("vanieriot/photoValue1")
    client.subscribe("vanieriot/temperature1")
    client.subscribe("vanieriot/humidity1")
    client.subscribe("vanieriot/RFID")


# initialize app
app = dash.Dash(
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        "/assets/style.css",
        "https://fonts.googleapis.com/css?family=Roboto",
    ]
)
app.title = "Final Project"

# sidebar design
sidebar = html.Div(
    [
        html.H6("IoT", className="display-block text-center fs-1"),
        html.H6("Dashboard", className="display-block text-center fs-1"),
        html.Hr(),
        html.P("Name: ", id="name", className="text-left fs-4 mx-4"),
        html.P("Temperature: ", id="temperature",  className="text-left fs-4 mx-4"),
        html.P("Humidity: ", id="humidity", className="text-left fs-4 mx-4"),
        html.P("Light Intensity: ", id="light", className="text-left fs-4 mx-4"),
    ],
    className="sidebar d-flex flex-column flex-shrink-0 p-2 text-white bg-dark",
    style={"width": "400px"}
)
# gauge design
gauge = html.Div(
    [
        html.Div(
            [
                html.H3(
                    "Temperature",
                    className="bold text-center p-4 text-light",
                ),
                daq.Gauge(
                    id="temp-gauge",
                    label={
                        # gets temperature from static value
                        "label": "{:.2f}°C".format(temp),
                        "style": {
                            "fontSize": "20px",
                            "fontWeight": "bold",
                            "fontFamily": "Roboto, sans-serif",
                            "color": "white",
                        },
                    },
                    color={
                        "gradient": True,
                        "ranges": {
                            "#00C0F5": [0, 25],
                            "#E3FC00": [25, 50],
                            "#FFBB00": [50, 75],
                            "red": [75, 100],
                        },
                    },
                    value=temp,
                    min=0,
                    max=100,
                    labelPosition="bottom",
                    style={
                        "textAlign": "center",
                        "fontFamily": "Roboto, sans-serif",
                        "color": "white",
                        "height": "30vh",
                    },
                    scale=3,
                    showCurrentValue=False,
                ),
            ],
            className="gauge card text-light mx-5",
            style={"background-color": "#1c1e22"},
        ),
        html.Div(
            [
                html.H3(
                    "Humidity",
                    className="bold text-center p-4 text-light",
                ),
                daq.Gauge(
                    id="humi-gauge",
                    label={
                        # change temperature value here
                        "label": "{:}%".format(humi),
                        "style": {
                            "fontSize": "20px",
                            "fontWeight": "bold",
                            "fontFamily": "Roboto, sans-serif",
                            "color": "white",
                        },
                    },
                    color={
                        "gradient": True,
                        "ranges": {
                            "#00FFF7": [0, 33],
                            "#00BBFF": [33, 66],
                            "#0022FF": [66, 100],
                        },
                    },
                    value=humi,
                    min=0,
                    max=100,
                    labelPosition="bottom",
                    style={
                        "textAlign": "center",
                        "fontFamily": "Roboto, sans-serif",
                        "color": "white",
                        "height": "30vh",
                    },
                    scale=3,
                    showCurrentValue=False,
                ),
            ],
            className="card text-light mx-5 mt-5",
            style={"background-color": "#1c1e22"},
        ),
    ],
    className="",
    style={"height": "100vh"},
)


@app.callback(
    Output("temp-gauge", "value"),
    Output("temp-gauge", "label"),
    Output("humi-gauge", "value"),
    Output("humi-gauge", "label"),
    Input("interval-component", "n_intervals"),
)
def update_values(n):
    # update temperature and humidity values here
    global temp
    global humi

    # update temperature gauge
    temp_value = temp
    temp_label = "{:.2f}°C".format(temp)

    # update humidity gauge
    humi_value = humi
    humi_label = "{:}%".format(humi)

    return temp_value, temp_label, humi_value, humi_label


slider = html.Div(
    [
        html.Div(
            className="card m-5",
            style={
                "background-color": "#1c1e22",
                "width": "325px",
                "text-align": "center",
                "margin-bottom": "10px",
            },
            children=[
                html.H3("Light Intensity", className="bold text-center p-4 text-light"),
                html.Img(
                    src="https://www.onlygfx.com/wp-content/uploads/2022/03/sun-clipart-set-5.png",
                    className="img-fluid mx-auto",
                    style={"width": "60px", "height": "60px", "margin-top": "20px"},
                ),
                html.Div(
                    style={"padding-top": "10px", "padding-left": "23px"},
                    children=[
                        dcc.Slider(
                            id="my-slider",
                            min=0,
                            max=1000,
                            value=700,
                            step=200,
                            vertical=True,
                            disabled=True,
                            className="slider-container d-flex justify-content-center align-items-center m-auto",
                        ),
                        html.P(
                            "",
                            id="slider-value",
                            className="text-light m-5 fs-3",
                            style={"padding-right": "22px"},
                        ),
                    ],
                ),
                #html.P(
                 #   "Email Status",
                 #   className="text-light fs-3",
                 #   style={"textDecoration": "underline"},
                #),
                #html.P("Email has been received", className="text-light fs-5"),
            ],
        )
    ],
    className="my-4",
    style={"height": "105vh"},
)


@app.callback(
    [Output("slider-value", "children"), Output("my-slider", "value")],
    [Input("interval-component", "n_intervals")],
)
def update_slider_value(n):
    global lightsensor

    return [f"{lightsensor}", lightsensor]


status = html.Div(
    [
        html.Div(
            [
                html.H3(
                    "LED Status",
                    className="bold text-center p-4 text-light",
                ),
                html.Img(
                    id="led-image",
                    src="/assets/led-off.png",
                    className="img-fluid mx-auto my-5",
                    style={"width": "100px", "height": "100px", "margin-top": "20px"},
                ),
                daq.PowerButton(
                    id="our-power-button-1",
                    on=False,
                    color="#faf561",
                    style={"padding-bottom": "20px"},
                ),
            ],
            className="card text-light mx-5",
            style={
                "background-color": "#1c1e22",
                "margin-bottom": "20px",
                "pointer-events": "none",
            },  # add margin to the bottom of the card
        ),
        html.Div(
            [
                html.H3(
                    "Fan Status",
                    className="bold text-center p-4 text-light",
                ),
                html.Img(
                    src="/assets/off-blue-fan.png",
                    className="img-fluid mx-auto my-5",
                    style={"width": "100px", "height": "100px", "margin-top": "20px"},
                ),
                daq.PowerButton(
                    id="our-power-button-2",
                    on=False,
                    color="#61e1fa",
                    style={"padding-bottom": "20px", "pointer-events": "none"},
                ),
            ],
            className="card text-light mx-5 mt-5",
            style={
                "background-color": "#1c1e22",
                "margin-top": "20px",
            },  # add margin to the top of the card
        ),
    ],
    className="",
    style={"width": "400px", "height": "100vh"},
)


@app.callback(
    Output("led-image", "src"),
    Input("our-power-button-1", "on"),
)
def update_image(on):
    global lightsensor
    global lightpref
    
    if lightsensor <= lightpref:
        return "/assets/on.png"
    else:
        return "/assets/led-off.png"


app.layout = html.Div(
    [
        dcc.Interval(id="interval-component", interval=5 * 1000, n_intervals=0),
        dbc.Row(
            [
                dbc.Col(sidebar, style={"width": "600px"}),
                dbc.Col(gauge),
                dbc.Col(slider),
                dbc.Col(status),
            ],
            style={"align-items": "center"},
        ),
    ],
    className="bg-dark",
)


# create a callback function that updates the email status text
@app.callback(
    Output("email-status", "children"),
    [Input("interval-component", "n_intervals")],
)
def update_email_status(n):
    global lightsensor
    global lightpref
    
    if (lightsensor <= lightpref):
        return "Email has been sent to fehambros"



# create an interval component that updates every 5 seconds
@app.callback(
    Output("interval-component", "interval"),
    [Input("interval-component", "n_intervals")],
)
def update_interval(n):
    return 5 * 1000

@app.callback(
    [Output("name", "children"),
     Output("temperature", "children"),
     Output("humidity", "children"),
     Output("light", "children")],
    [Input("interval-component", "n_intervals")]
)
def update_sidebar_data(n):
    # Get the latest data from your IoT device or database
    global name
    global humipref
    global temppref
    global lightpref

    # Update the text in the P tags
    return (
        f"Name: {name}",
        f"Temperature: {temppref}",
        f"Humidity: {humipref}",
        f"Light Intensity: {lightpref}",
    )

# create a function that updates hasLEDEmailSent
def update_email_sent_status():
    global hasLEDEmailSent

    # do some check to update hasLEDEmailSent
    hasLEDEmailSent = True

# Define the callback function for the button
@app.callback(Output("output", "children"), Input("button", "n_clicks"))
def update_output(n_clicks):
    if n_clicks % 2 == 1:
        print(n_clicks % 2)
        # turns off motor
        GPIO.output(Motor1, GPIO.LOW)
        # returns updated img
        return ""
    else:
        print(n_clicks % 2)
        # turns on motor
        motor_on()
        return ""


# runs server
if __name__ == "__main__":
    client = mqtt.Client()
    client.connect("0.0.0.0", 1883)
    client.on_connect = on_connect
    client.on_message = on_message
    client.loop_start()
    app.run_server(debug=True)